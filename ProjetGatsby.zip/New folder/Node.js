const readline = require('readline');
const fs = require('fs');
const { execSync } = require('child_process');

const spinnerChars = ['/', '-', '\\', '|'];

// Create a readline interface
const rl = readline.createInterface({
    input: process.stdin,
    output: process.stdout
});

// Initialize the spinner index
let spinnerIndex = 0;

rl.question('Nom du projet? ', (projectName) => {
    projectName = projectName || 'my-wordpress-project';

    rl.question('Project base URL? (test.docker.localhost) ', (baseUrl) => {
        baseUrl = baseUrl || 'test.docker.localhost';

        rl.question('Database name? (wordpress) ', (dbName) => {
            dbName = dbName || 'wordpress';

            rl.question('Database user? (root) ', (dbUser) => {
                dbUser = dbUser || 'root';

                rl.question('Database password? (empty) ', (dbPassword) => {
                    dbPassword = dbPassword;

                    rl.question('Database root password? (empty) ', (dbRootPassword) => {
                        dbRootPassword = dbRootPassword;

                        rl.question('Précharger la base de données avec des données fictives ? (y/N) ', (prepopulateDb) => {
                            prepopulateDb = prepopulateDb.toLowerCase() === 'y';

                            rl.question('Install WooCommerce? (y/N) ', (installWooCommerce) => {
                                installWooCommerce = installWooCommerce.toLowerCase() === 'y';

                                rl.close();

                                // Check if the project directory already exists
                                if (fs.existsSync(projectName)) {
                                    console.error(`Le répertoire "${projectName}" existe déjà.`);
                                    return;
                                }

                                // Create the database
                                const createDatabase = `mysql -uroot -p${dbRootPassword} -e "CREATE DATABASE IF NOT EXISTS ${dbName}"`;
                                execSync(createDatabase);

                                // install Bedrock 
                                const gitCommand = `composer create-project roots/bedrock ${projectName}`;
                                execSync(gitCommand);

                                // Change working directory to the Bedrock directory
                                process.chdir(`${projectName}`);

                                // Generate the .env file
                                const envContent = `
                                    DB_NAME=${dbName}
                                    DB_USER=${dbUser}
                                    DB_PASSWORD=${dbPassword}
                                    DB_ROOT_PASSWORD=${dbRootPassword}
                                    WP_ENV=development
                                    WP_HOME=http://${baseUrl}
                                    WP_SITEURL=http://${baseUrl}/wp
                                `;
                                fs.writeFileSync('.env', envContent);

                                // Install and activate WooCommerce if requested
                                if (installWooCommerce) {
                                    execSync('composer require wpackagist-plugin/woocommerce');
                                }

                                // Install plugins
                                execSync('composer require wpackagist-plugin/gutenberg');
                                execSync('composer require wpackagist-plugin/autodescription');
                                execSync('composer require wpackagist-plugin/advanced-custom-fields');
                                execSync('composer require wpackagist-plugin/duplicate-wp-page-post');
                                execSync('composer require tinymce/tinymce');
                                execSync('composer require wpackagist-plugin/wp-gatsby');
                                execSync('composer require wpackagist-plugin/wp-graphql');
                                execSync('composer require wp-graphql/wp-graphql-acf');

                                // Remove default WordPress themes
                                const rimraf = require('rimraf');
                                rimraf.sync('web/app/themes/twentytwentythree');

                                // Add custom domain name to hosts file
                                const hostsFilePath = '/etc/hosts'; // Change this if your hosts file is located elsewhere
                                const hostsFileContent = fs.readFileSync(hostsFilePath, 'utf8');
                                const newHostsFileContent = `${hostsFileContent}\n127.0.0.1 ${baseUrl}`;
                                fs.writeFileSync(hostsFilePath, newHostsFileContent);

                                // Start the PHP server
                                const startServer = `php -S ${baseUrl}:80 -t web`;
                                execSync(startServer);

                                console.log(`Bedrock WordPress project "${projectName}" created successfully.`);
                            });
                        });
                    });
                });
            });
        });
    });
});
