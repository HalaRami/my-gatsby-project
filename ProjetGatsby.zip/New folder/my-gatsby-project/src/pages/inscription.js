import React, { useState } from "react";
import "../styles/inscription.css";
import Header from "../components/header/header";
import Footer from "../components/footer/footer";

const RegistrationPage = () => {
  const [username, setUsername] = useState("");
  const [password, setPassword] = useState("");
  const [confirmPassword, setConfirmPassword] = useState("");
  const [errorMessage, setErrorMessage] = useState("");

  const handleRegistration = (e) => {
    e.preventDefault();

    // Vérification des champs (à adapter selon vos besoins)
    if (username === "" || password === "" || confirmPassword === "") {
      setErrorMessage("Veuillez remplir tous les champs");
    } else if (password !== confirmPassword) {
      setErrorMessage("Les mots de passe ne correspondent pas");
    } else {
      // Effectuer l'inscription (à adapter selon vos besoins)
      // ...
      // Rediriger vers une autre page
      window.location.href = "/dashboard";
    }
  };

  return (
    <>
    <Header/>
    <div className="registration-page">
      <h2>Page d'inscription</h2>
      <form className="registration-form" onSubmit={handleRegistration}>
        <div>
          <label htmlFor="username">Nom d'utilisateur:</label>
          <input
            type="text"
            id="username"
            value={username}
            onChange={(e) => setUsername(e.target.value)}
          />
        </div>
        <div>
          <label htmlFor="password">Mot de passe:</label>
          <input
            type="password"
            id="password"
            value={password}
            onChange={(e) => setPassword(e.target.value)}
          />
        </div>
        <div>
          <label htmlFor="confirmPassword">Confirmer le mot de passe:</label>
          <input
            type="password"
            id="confirmPassword"
            value={confirmPassword}
            onChange={(e) => setConfirmPassword(e.target.value)}
          />
        </div>
        {errorMessage && <p>{errorMessage}</p>}
        <button type="submit">S'inscrire</button>
      </form>
    </div>
    <Footer/>
    </>
  );
};

export default RegistrationPage;
