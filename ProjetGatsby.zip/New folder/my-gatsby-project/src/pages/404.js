import React from "react";
import Layout from "../layout/layout";
import "../styles/404.css";
const NotFoundPage = () => (
  <Layout>
    <div className="not-found-page">
      <h1>Page non trouvée</h1>
      <p>Vous avez atteint une page qui n'existe pas... quelle tristesse.</p>
    </div>
  </Layout>
);

export default NotFoundPage;
