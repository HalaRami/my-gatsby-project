import React from "react";
import Layout from "../layout/layout";
import Card from '@mui/material/Card';
import CardMedia from '@mui/material/CardMedia';

import { Paper, Typography, Grid, Container, Avatar } from '@mui/material';
import { makeStyles } from "@material-ui/core/styles";
import { useStaticQuery, graphql } from "gatsby";



const useStyles = makeStyles(theme => ({
  root: {
    "& > *": theme.spacing(1),
  },
  media: {
    background: "linear-gradient(rgba(0,0,0,0.2),rgba(0,0,0,0.38)),url('images/background.avif') 50%  no-repeat fixed",
    backgroundSize: "cover",
    height: 500,
    display: "flex",
    flexDirection: "column",
    alignItems: "center",
    justifyContent: "center",
    color: "#fff",
  },
  heading: {
    fontSize: 77,
    margin: 0,
    textShadow: "2px 1px 8px rgba(0, 0, 0, 0.75)",
    color: "#fff",
  },
  sectionHeading: {
    fontFamily: "Oswald",
    textAlign: "center",
    padding: "20px 0 30px 0",

  },
  huge: {
    width: "100%",
    height: "100%",
  },
  clothes: {
    marginTop:"10px",
    fontSize: "50px"
  }
  
}));

const IndexPage = () => {
  const classes = useStyles();

  const aboutdata = useStaticQuery(graphql`
  query {
    wpPage(databaseId: {eq: 33}) {
      id
      title
      content
    }
  }
  `)

  return (
    <Layout>
      <section id="HOME">
        <Card className={classes.root}>
          <CardMedia className={classes.media}>
            <h1 className={classes.heading}>H&I</h1>
            <h2 className={classes.clothes}>Clothes</h2>
          </CardMedia>
        </Card>
      </section>

      <section id="ABOUT" style={{marginTop: -64, paddingTop: 64}} >
        {/*About */}
        <Paper square style={{ paddingBottom: 30 }}>
          <Container maxWidth="lg">
            <Typography variant="h3" className={classes.sectionHeading}>
              SHORT ABOUT H&I!
            </Typography>
            <Grid container spacing={3}>
              <Grid item xs={12} sm={6} md={3}>
                <Avatar src="images/loogo.jpeg" className={classes.huge} />
              </Grid>
              <Grid item xs={12} sm={6} md={9}>
                <Typography variant="body1" dangerouslySetInnerHTML={{__html:aboutdata.wpPage.content}} />
                  
                
              </Grid>
            </Grid>
          </Container>
        </Paper>
      </section>
      
      <section>
        {/*Contact */}

      </section>
    </Layout>
  );
}

export default IndexPage;
