import React, { useState } from "react";
import "../styles/authentification.css";
import Header from "../components/header/header";
import Footer from "../components/footer/footer";
const LoginPage = () => {
  const [username, setUsername] = useState("");
  const [password, setPassword] = useState("");
  const [errorMessage, setErrorMessage] = useState("");

  const handleLogin = (e) => {
    e.preventDefault();

    // Vérification des identifiants (à adapter selon vos besoins)
    if (username === "admin" && password === "password") {
      // Authentification réussie, rediriger vers une autre page
      window.location.href = "/dashboard";
    } else {
      // Afficher un message d'erreur si l'authentification échoue
      setErrorMessage("Nom d'utilisateur ou mot de passe incorrect");
    }
  };

  return (
    <>
    <Header/>
    <div className="login-page">
      <h2>Page d'authentification</h2>
      <form  className="login-form" onSubmit={handleLogin}>
        <div>
          <label htmlFor="username">Nom d'utilisateur:</label>
          <input
            type="text"
            id="username"
            value={username}
            onChange={(e) => setUsername(e.target.value)}
          />
        </div>
        <div>
          <label htmlFor="password">Mot de passe:</label>
          <input
            type="password"
            id="password"
            value={password}
            onChange={(e) => setPassword(e.target.value)}
          />
        </div>
        {errorMessage && <p>{errorMessage}</p>}
        <button type="submit">Se connecter</button>
      </form>
    </div>
    <Footer/>
    </>
  );
};

export default LoginPage;
