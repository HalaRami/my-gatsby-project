import React from "react";
import { graphql } from "gatsby";
import Header from "../components/header/header";
import Footer from "../components/footer/footer";
import "./page.css";


const PageTemplate = ({ data }) => {
  const { title, content } = data.wpPage;

  return (
    <div className="all">
      <Header />
      <h1>{title}</h1>
      <div dangerouslySetInnerHTML={{ __html: content }} />
      <Footer />
    </div>
  );
};

export const query = graphql`
  query($slug: String) {
    wpPage(slug: { eq: $slug }) {
      title
      content
    }
  }
`;

export default PageTemplate;
