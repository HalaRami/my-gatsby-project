import React from "react";
import Header from "../components/header/header";
import Footer from "../components/footer/footer";
import "./panier.css";
import RemovePanier from "./RemovePanier";
import CalculTotalPanier from "./CalculTotalPanier";

const Cart = () => {
  const cartItems = JSON.parse(localStorage.getItem("cart")) || [];


  return (
    <>
      <Header />
      <div className="cart">
        <h1 className="cart-title">Cart</h1>
        <div className="cart-wrapper">
          {cartItems && Array.isArray(cartItems) && cartItems.length === 0 ? (
            <div className="empty-cart">Your cart is empty.</div>
          ) : (
            cartItems.map((item) => (
              <div className="cart-item" key={item.slug}>
                <div className="cart-item-img-wrapper">
                  <img
                    src={item.featuredImage.node.sourceUrl}
                    alt={item.title}
                    className="cart-item-img"
                  />
                </div>
                <div className="cart-item-info">
                  <div className="cart-item-title">{item.title}</div>
                  <div className="cart-item-quantity">
                    Quantity: <span>{item.quantity}</span>
                  </div>
                  <div className="cart-item-price">
                    Price: <span>{item.price.replace(/&nbsp;/g, "")}</span>
                  </div>
                  <section>
                    <RemovePanier slug={item.slug} />
                  </section>
                </div>
              </div>
            ))
          )}
         <section>
          <CalculTotalPanier/>
         </section>
        </div>
      </div>
      <Footer />
    </>
  );
};

export default Cart;
