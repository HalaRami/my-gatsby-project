import React, { useState, useMemo } from "react";
import { makeStyles } from "@material-ui/core/styles";
import { Paper, Typography, Container } from "@mui/material";
import { graphql } from "gatsby";
import Header from "../components/header/header";
import Footer from "../components/footer/footer";
import BlogSearch from './BlogSearch';
import BlogProduct from "./BlogProduct";

const useStyles = makeStyles({
  container: {
    marginTop: 40,
    marginBottom: 40,
  },
  sectionHeading: {
    fontFamily: "Arial",
    textAlign: "center",
    fontSize: 24,
    fontWeight: "bold",
    color: "#333",
    marginBottom: 20,
    marginTop: 100,
  },
});

const ProductTemplate = ({ data }) => {
  const classes = useStyles();

  const [searchQuery, setSearchQuery] = useState("");

  // Filtrer les produits en fonction de la recherche
  const filteredProducts = useMemo(() => {
    if (!searchQuery) {
      return data.allWpSimpleProduct.nodes;
    }

    return data.allWpSimpleProduct.nodes.filter((node) =>
      node.title.toLowerCase().includes(searchQuery.toLowerCase())
    );
  }, [data.allWpSimpleProduct.nodes, searchQuery]);

  return (
    <div>
      <Header />
      <section id="PRODUCTS" className={classes.container}>
        {/* Products */}
        <Paper square>
          <Container maxWidth="lg">
            <Typography variant="h3" className={classes.sectionHeading}>
              Some of our Products
            </Typography>

            <section id="BLOG">
              <BlogSearch searchQuery={searchQuery} setSearchQuery={setSearchQuery} />
            </section>
            <section id="BLOGPRODUCT">
              <BlogProduct data={filteredProducts} />
            </section> 
            
          </Container>
        </Paper>
      </section>
      <Footer />
    </div>
  );
};

export const query = graphql`
query {
  allWpSimpleProduct {
    nodes {
      featuredImage {
        node{
        sourceUrl
      }
      }
      id
      price
      productCategories {
        nodes {
          name
        }
      }
      slug
      title
    }
  }
}
`;

export default ProductTemplate;
