import React from "react";

const RemovePanier = ({ slug }) => {
  const cartItems = JSON.parse(localStorage.getItem("cart")) || [];

  const removeItem = (slug) => {
    const updatedCart = cartItems.filter((item) => item.slug !== slug);
    localStorage.setItem("cart", JSON.stringify(updatedCart));
    window.location.reload();
  };

  return (
    <button className="cart-item-delete-icon" onClick={() => removeItem(slug)}>
      Remove
    </button>
  );
};

export default RemovePanier;
