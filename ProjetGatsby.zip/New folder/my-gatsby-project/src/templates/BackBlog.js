import React from "react";
import { Link } from "gatsby";

const BackBlog = () => {

    return (
        <div>
            <Link to="/products">
                <button  className="add-to-cart-btn" >Back to Products</button>
            </Link>
        </div>

    )
}

export default BackBlog;