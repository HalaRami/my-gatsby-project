import React from "react";
import { graphql } from "gatsby";
import Header from "../components/header/header";
import Footer from "../components/footer/footer";
import "./SingleProduct.css";
import AddToCartBlog from "./AddToCartBlog";
import BackBlog from "./BackBlog";

const SingleProduct = (props) => {
  const product = props.data.wpSimpleProduct;

  return (
    <div>
      <Header />
      <section>
        <AddToCartBlog data={props.data} />
      </section>

      <section>
        <BackBlog />
      </section>

      <p
        dangerouslySetInnerHTML={{ __html: product.description }}
        className="desc"
      ></p>

      <Footer />
    </div>
  );
};

export const query = graphql`
  query ($slug: String) {
    wpSimpleProduct(slug: { eq: $slug }) {
      price
      slug
      title
      featuredImage {
        node {
          sourceUrl
        }
      }
      description
    }
  }
`;

export default SingleProduct;
