import React from 'react';
import TextField from '@material-ui/core/TextField';
import { makeStyles } from "@material-ui/core/styles";

const useStyles = makeStyles({
  searchContainer: {
    display: "flex",
    justifyContent: "center",
    marginBottom: 20,
  },
});

function BlogSearch({ searchQuery, setSearchQuery }) {
  const classes = useStyles();

  const handleSearchChange = (e) => {
    setSearchQuery(e.target.value);
  };

  return (
    <div className={classes.searchContainer}>
      <TextField
        label="Search Products"
        variant="outlined"
        value={searchQuery}
        onChange={handleSearchChange}
      />
    </div>
  );
}

export default BlogSearch;
