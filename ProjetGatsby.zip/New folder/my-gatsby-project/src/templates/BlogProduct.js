import React from "react";
import { Link } from "gatsby";
import { Grid, Card, CardActionArea, CardMedia, CardContent, Typography, CardActions, Button } from "@mui/material";
import { makeStyles } from "@mui/styles";

const useStyles = makeStyles({
  blogContainer: {
    marginTop: 40,
    marginBottom: 40,
  },
  blogCard: {
    width: "100%",
    marginBottom: 20,
    boxShadow: "0px 2px 4px rgba(0, 0, 0, 0.1)",
  },
  blogMedia: {
    height: 260,
  },
  blogTitle: {
    fontSize: 18,
    fontWeight: "bold",
    marginBottom: 8,
  },
  blogDate: {
    fontSize: 14,
    marginBottom: 8,
  },
  blogContent: {
    fontSize: 14,
    marginBottom: 8,
    color: "#666",
  },
  readMoreButton: {
    backgroundColor: "#ff5722",
    color: "#fff",
    "&:hover": {
      backgroundColor: "#ff5722",
      opacity: 0.8,
    },
  },
});

const BlogProduct = ({ data }) => {
  const classes = useStyles();

  return (
    <Grid container spacing={3} className={classes.blogContainer}>
      {/* Blog Card */}
      {data.map((node) => (
        <Grid item xs={12} sm={6} md={4} key={node.id}>
          <Card className={classes.blogCard}>
            <CardActionArea>
              <Link to={`/SingleProduct/${node.slug}`}>
                <CardMedia
                  className={classes.blogMedia}
                  image={node.featuredImage.node.sourceUrl}
                  alt=""
                />
              </Link>
            </CardActionArea>
            <CardContent>
              <Typography
                variant="h5"
                component="h2"
                className={classes.blogTitle}
              >
                {node.title}
              </Typography>
              <Typography
                variant="body2"
                color="textSecondary"
                component="div"
                className={classes.blogDate}
              >
                Price: {node.price}
              </Typography>
              <Typography
                variant="body2"
                color="textSecondary"
                component="div"
                className={classes.blogContent}
              >
                Category: {node.productCategories.nodes[0].name}
              </Typography>
            </CardContent>
            <CardActions>
              <Grid container alignItems="center" justify="center">
                <Link to={`/SingleProduct/${node.slug}`}>
                  <Button
                    variant="contained"
                    size="small"
                    className={classes.readMoreButton}
                  >
                    Buy Now
                  </Button>
                </Link>
              </Grid>
            </CardActions>
          </Card>
        </Grid>
      ))}
      {/* End Blog Card */}
    </Grid>
  );
};

export default BlogProduct;
