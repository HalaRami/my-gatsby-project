import React, { useState } from "react";
import { navigate } from "gatsby";

const AddToCartBlog = ({ data }) => {
  const product = data.wpSimpleProduct;
  const [quantity, setQuantity] = useState(1);

  const handleQuantityChange = (event) => {
    setQuantity(event.target.value);
  };

  const addToCart = () => {
    const selectedProduct = {
      ...product,
      quantity: parseInt(quantity),
    };

    const existingCart = localStorage.getItem("cart");
    let updatedCart = [];

    if (existingCart) {
      updatedCart = JSON.parse(existingCart);
    }

    updatedCart.push(selectedProduct);
    localStorage.setItem("cart", JSON.stringify(updatedCart));

    navigate("/panier");
  };

  return (
    <div className="single-product">
      <div className="product-wrapper">
        <div className="product-image-wrapper">
          <img src={product.featuredImage.node.sourceUrl} alt="" />
        </div>
        <div className="product-info">
          <h1 className="product-title">{product.title}</h1>
          <div
            className="product-price"
            dangerouslySetInnerHTML={{ __html: product.price }}
          ></div>
          <div className="product-add-to-cart">
            <div>
              Quantity:
              <input
                type="number"
                min="1"
                max="10"
                name="quantity"
                value={quantity}
                onChange={handleQuantityChange}
              />
            </div>
            <button className="add-to-cart-btn" onClick={addToCart}>
              Add to cart
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};

export default AddToCartBlog;
