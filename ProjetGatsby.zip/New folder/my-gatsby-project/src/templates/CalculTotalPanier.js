import React from "react";
import { Link } from "gatsby";

const CalculTotalPanier = () => {
  const cartItems = JSON.parse(localStorage.getItem("cart")) || [];

  const calculateTotalPrice = () => {
    let totalPrice = 0;
    const priceRegex = /(\d+(\.\d{1,2})?)/;

    cartItems.forEach((item) => {
      const match = item.price.match(priceRegex);
      if (match && match[1]) {
        const cleanedPrice = parseFloat(match[1].replace(/[^0-9.-]+/g, ""));
        const parsedQuantity = parseInt(item.quantity);
        const subtotal = cleanedPrice * parsedQuantity;
        totalPrice += subtotal;
      }
    });

    return totalPrice.toFixed(2);
  };

  return (
    <div>
      {cartItems && Array.isArray(cartItems) && cartItems.length > 0 && (
        <div className="cart-summary">
          <div className="cart-summary-text">
            <i className="bi bi-check-circle-fill"></i>
            Your order has been placed successfully!
          </div>
          <div className="cart-summary-total">
            Total: <span>{calculateTotalPrice()}د.م</span>
          </div>
          <Link to="/products">
            <button className="cart-summary-btn">Continue Shopping</button>
          </Link>
        </div>
      )}
    </div>
  );
};

export default CalculTotalPanier;
