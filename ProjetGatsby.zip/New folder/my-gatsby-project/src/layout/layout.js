import React from "react";
import { ThemeProvider, CssBaseline } from "@material-ui/core";
import Header from "../components/header/header";
import Footer from "../components/footer/footer";
import Theme from "../theme";
import "../styles/style.css";

const Layout = (props) => {
  return (
    <ThemeProvider theme={Theme}>
      <CssBaseline />
      <Header />
      <div className="wrapper">{props.children}</div>
      <Footer />
    </ThemeProvider>
  );
};

export default Layout;
