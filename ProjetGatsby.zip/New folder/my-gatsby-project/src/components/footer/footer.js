import React from "react";
import * as footerStyles from "./footer.module.css";

const Footer = () => {
  return (
    <div className={footerStyles.footer}>
      <div className={`${footerStyles.sb__footer} ${footerStyles.section__padding}`}>
        <div className={footerStyles.sb__footerLinks}>
          <div className={footerStyles.sb__footerLinksDiv}>
            <h4>For Business</h4>
            <a href="/employer">
              <p>Employer</p>
            </a>
            <a href="/healthplan">
              <p>Health Plan</p>
            </a>
            <a href="/individual">
              <p>Individual</p>
            </a>
          </div>
          <div className={footerStyles.sb__footerLinksDiv}>
            <h4>Resources</h4>
            <a href="/resource">
              <p>Resource center</p>
            </a>
            <a href="/resource">
              <p>Testimonials</p>
            </a>
            <a href="/resource">
              <p>STV</p>
            </a>
          </div>
          <div className={footerStyles.sb__footerLinksDiv}>
            <h4>Partners</h4>
            <a href="/employer">
              <p>Swing Tech</p>
            </a>
          </div>
          <div className={footerStyles.sb__footerLinksDiv}>
            <h4>Company</h4>
            <a href="/about">
              <p>About</p>
            </a>
            <a href="/press">
              <p>Press</p>
            </a>
            <a href="/career">
              <p>Career</p>
            </a>
            <a href="/contact">
              <p>Contact</p>
            </a>
          </div>
          <div className={footerStyles.sb__footerLinksDiv}>
            <h4>Coming soon on</h4>
            <div className={footerStyles.socialMedia}>
              <p>
                <a href="/facebook">Facebook</a>
              </p>
              <p>
                <a href="/twitter">Twitter</a>
              </p>
              <p>
                <a href="/whatsapp">WhatsApp</a>
              </p>
              <p>
                <a href="/instagram">Instagram</a>
              </p>
            </div>
          </div>
        </div>

        <hr />

        <div className={footerStyles.sb__footerBelow}>
          <div className={footerStyles.sb__footerCopyright}>
            <p>@{new Date().getFullYear()} CodeInn. All rights reserved.</p>
          </div>
          <div className={footerStyles.sb__footerBelowLinks}>
            <a href="/terms">
              <div>
                <p>Terms &amp; Conditions</p>
              </div>
            </a>
            <a href="/privacy">
              <div>
                <p>Privacy</p>
              </div>
            </a>
            <a href="/security">
              <div>
                <p>Security</p>
              </div>
            </a>
            <a href="/cookie">
              <div>
                <p>Cookie Declaration</p>
              </div>
            </a>
          </div>
        </div>
      </div>
    </div>
  );
};

export default Footer;
