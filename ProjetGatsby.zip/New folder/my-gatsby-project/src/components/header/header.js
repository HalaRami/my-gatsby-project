import React from "react";
import { Link, graphql, useStaticQuery } from 'gatsby';
import * as headerStyles from "./header.module.css";
import { makeStyles } from "@mui/styles";

import { AppBar, Toolbar, IconButton, Typography, MenuItem, Menu, } from "@mui/material";
import { Avatar } from "@mui/material";


import MoreIcon from "@mui/icons-material/More";


const useStyles = makeStyles(theme => ({
  grow: {
    flexGrow: 1,
  },
  sectionDesktop: {
    display: "none",
    [theme.breakpoints.up("md")]: {
      display: "flex",
    },
  },
  sectionMobile: {
    display: "flex",
    [theme.breakpoints.up("md")]: {
      display: "none",
    },
  },
  large: {
    width: theme.spacing(7),
    height: theme.spacing(7),
  },
}));

const Header = () => {


  const data = useStaticQuery(graphql`
  query{
    site{
      siteMetadata{
        author
        description
        title
        image
      }
    }
    wpMenu(name:{eq:"mainMenu"}){
      menuItems{
        nodes{
          label
          url
          parentId
          id
        }
      }
    }
  }
  `

  );
  const menuItems = data.wpMenu.menuItems.nodes;



  const classes = useStyles();

  const [mobileMoreAnchorE1, setMobileMoreAnchorE1] = React.useState(null);
  const isMobileMenuOpen = Boolean(mobileMoreAnchorE1);

  const handleMobileMenuClose = () => {
    setMobileMoreAnchorE1(null);
  };

  const handleMobileMenuOpen = event => {
    setMobileMoreAnchorE1(event.currentTarget);
  };

  const mobileMenuId = "menu";
  const renderMobileMenu = (
    <Menu
      anchorEl={mobileMoreAnchorE1}
      anchorOrigin={{ vertical: "top", horizontal: "right" }}
      id={mobileMenuId}
      keepMounted
      transformOrigin={{ vertical: "top", horizontal: "right" }}
      open={isMobileMenuOpen}
      onClose={handleMobileMenuClose}
    >
      {menuItems.map(item => (
        <MenuItem key={item.id}>
          <Typography variant="body1">
            <Link className={headerStyles.linkformobile} to={item.url}>
              {item.label}
            </Link>
          </Typography>
        </MenuItem>
      ))}
    </Menu>
  )


  return (
    <div className={classes.grow}>
      <AppBar position="fixed" className="main-header">
        <Toolbar>
          <Typography variant="h6" noWrap className={headerStyles.link}>
            <Link to="/">

              <Avatar
                src={data.site.siteMetadata.image}
                alt={data.site.siteMetadata.title}
                title={data.site.siteMetadata.title}
                className={classes.large}
              />

            </Link>
          </Typography>

          <div className={classes.grow} />

          <div className={classes.sectionDesktop}>
            {/* Render desktop menu items dynamically from the query */}
            {menuItems.map(item => (
              <Typography variant="body1" className={headerStyles.link} key={item.id}>
                <Link to={item.url}>{item.label}</Link>
              </Typography>
            ))}
          </div>

          <div className={classes.sectionMobile}>
            <IconButton
              aria-label={mobileMenuId}
              aria-controls={mobileMenuId}
              aria-haspopup="true"
              onClick={handleMobileMenuOpen}
              color="inherit"
            >
              <MoreIcon />
            </IconButton>
          </div>
        </Toolbar>
      </AppBar>
      {renderMobileMenu}

    </div>
  )
}
export default Header