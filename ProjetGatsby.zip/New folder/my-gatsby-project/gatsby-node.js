/**
 * Implement Gatsby's Node APIs in this file.
 *
 * See: https://www.gatsbyjs.com/docs/reference/config-files/gatsby-node/
 */

/**
 * @type {import('gatsby').GatsbyNode['createPages']}
 
exports.createPages = async ({ actions }) => {
  const { createPage } = actions
  createPage({
    path: "/using-dsg",
    component: require.resolve("./src/templates/using-dsg.js"),
    context: {},
    defer: true,
  })
}*/


const path = require("path");

exports.createPages = async ({ graphql, actions }) => {
  const { createPage } = actions;

  // Création des pages pour les produits
  const productResult = await graphql(`
    query {
      allWpProduct {
        nodes {
          slug
        }
      }
    }
  `);

  productResult.data.allWpProduct.nodes.forEach(product => {
    createPage({
      path: `/SingleProduct/${product.slug}`,
      component: path.resolve("./src/templates/SingleProduct.js"),
      context: {
        slug: product.slug,
      },
    });
  });

  // Création des pages pour le panier
  const cartResult = await graphql(`
    query {
      allWpSimpleProduct {
        nodes {
          slug
        }
      }
    }
  `);

  cartResult.data.allWpSimpleProduct.nodes.forEach(product => {
    createPage({
      path: `/panier/${product.slug}`,
      component: path.resolve("./src/templates/panier.js"),
      context: {
        slug: product.slug,
      },
    });
  });

  // Création des pages d'une manière dynamique
  const pageResult = await graphql(`
  query {
    allWpPage {
      nodes {
        slug
        title
        content
      }
    }
  }
 `);

  pageResult.data.allWpPage.nodes.forEach(page => {
    createPage({
      path: `/${page.slug}`,
      component: path.resolve("./src/templates/page.js"),
      context: {
        slug: page.slug,
      },
    });
  });

  
  

  

  exports.createPages = async ({ actions }) => {
    const { createPage } = actions;
  
    // Créer une page personnalisée pour l'erreur 404
    createPage({
      path: '/404',
      component: path.resolve('./src/templates/404Template.js'), 
    });
  };
  




};





